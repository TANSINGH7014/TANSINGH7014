<?php
require_once('./database/config.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo $webdata['webtag'];?></title>
  <meta content="<?php echo $webdata['webtag'];?>" name="descriptison">
  <meta content="<?php echo $webdata['webtag'];?>" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo $webdata['weblogo'];?>" rel="icon">
  <link href="<?php echo $webdata['weblogo'];?>" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
<!--Start of Tawk.to Script-->

<!--End of Tawk.to Script-->
  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Bootslander - v2.2.0
  * Template URL: https://bootstrapmade.com/bootslander-free-bootstrap-landing-page-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  
<style>
.about .video-box {
  background: url("assets/img/aadhar.jpg") center center no-repeat; 
  background-size: contain;
  min-height: 300px;
}

}
.icofont-navigation-menu{
    color: #000;
}
.mobile-nav-toggle i {
    color: #000;
}
</style>  
  
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center header-transparent bg-white">
    <div class="container d-flex align-items-center">

      <div class="logo mr-auto">
        <!--h1 class="text-light"><a href="index.html"><span>Bootslander</span></a></h1-->
        <!-- Uncomment below if you prefer to use an image logo -->
        <a href="index.php"><img src="<?php echo $webdata['weblogo'];?>" alt="" class="img-fluid"></a>
      </div>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.php" class="text-dark">Home</a></li>
          <!--li><a href="#OnlineCoupon" class="text-dark" data-toggle="modal" data-target="#BuyCoupon">Buy Coupon</a></li-->
          <!--li><a href="#about" class="text-dark">AePS</a></li-->
          <li><a href="#features" class="text-dark">Our Services</a></li>
          <li><a href="#pricing" class="text-dark">Pricing</a></li>
          <li><a href="#contact" class="text-dark">Contact</a></li>
          <li><a href="" class="text-dark"> UTI Crop Tool</a></li>
          <li><a href="/portallogin/login.php" class="text-dark"> Login</a></li>
          <li><a href="/portallogin/register.php" class="text-dark"> Register</a></li>
          

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">

    <div class="container">
      <div class="row">
        <div class="col-lg-7 pt-5 pt-lg-0 order-2 order-lg-1 d-flex align-items-center">
          <div data-aos="zoom-out">
            <h1>Build Your Own Portal With <span><?php echo $webdata['webtag'];?></span></h1>
            <h2>We at <span><?php echo $webdata['webtag'];?></span> provide Multi Software And Services, API Services, White label Portal, Software Development Solutions to Clients. </h2>
            <h2>Authorised Retailer, Distributor Platform</h2>
            <div class="text-center text-lg-left">
              <a href="#about" class="btn-get-started scrollto">Get Started</a>
            </div>
          </div>
        </div>
        <div class="col-lg-5 order-1 order-lg-2 hero-img" data-aos="zoom-out" data-aos-delay="300">
          <img src="assets/img/recharge.jpg" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

    <svg class="hero-waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 24 150 28 " preserveAspectRatio="none">
      <defs>
        <path id="wave-path" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z">
      </defs>
      <g class="wave1">
        <use xlink:href="#wave-path" x="50" y="3" fill="rgba(255,255,255, .1)">
      </g>
      <g class="wave2">
        <use xlink:href="#wave-path" x="50" y="0" fill="rgba(255,255,255, .2)">
      </g>
      <g class="wave3">
        <use xlink:href="#wave-path" x="50" y="9" fill="#fff">
      </g>
    </svg>

  </section><!-- End Hero -->

  <main id="main">
      <!-- ======= Details Section ======= -->
    <section id="details" class="details">
      <div class="container">

        <div class="row content">
          <div class="col-md-4" data-aos="fade-right">
            <img src="https://digisan.in/assets/img/details-1.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-8 pt-4" data-aos="fade-up">
            <h3>NSDL PAN CARD SERVICES</h3>
            <p class="font-italic">
              NSDL PAN Card. NSDL is the National Securities Depository Limited which was established in 1996.
               NSDL e-Governance Infrastructure Limited was originally set up as a Depository in 1995.
            </p>
            <ul>
              <li><i class="icofont-check"></i> Application Of New Pan Card </li>
              <li><i class="icofont-check"></i> Application Of Pan Card Correction  </li>
              <li><i class="icofont-check"></i> Application Of Lost or Damaged Pan Card</li>
              <li><i class="icofont-check"></i> Application Of Minor Pan Card</li>
            </ul>
            <p>
              Application for Allotment of Permanent Account Number
            </p>
          </div>
        </div>

       

        

        <div class="row content">
          <div class="col-md-4 order-1 order-md-2" data-aos="fade-left">
            <img src="https://digisan.in/assets/img/details-4.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-8 pt-5 order-2 order-md-1" data-aos="fade-up">
            <h3>UTI Infrastructure Technology And Services Limited (UTIITSL)</h3>
            <p class="font-italic">
              UTI Infrastructure Technology And Services Limited (UTIITSL) is a Government Company under section 2(45)
              of the Companies Act 2013, registered under the Companies Act 1956 since 1993.
            </p>
            
            <ul>
              <li><i class="icofont-check"></i> Application Of New Pan Card .</li>
              <li><i class="icofont-check"></i> Application Of Pan Card Correction</li>
              <li><i class="icofont-check"></i> Application Of Lost or Damaged Pan Card.</li>
            </ul>
          </div>
        </div>

      </div>
    </section><!-- End Details Section -->


    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container-fluid">

        <div class="row">
          <div class="col-xl-5 col-lg-6 video-box d-flex justify-content-center align-items-stretch" data-aos="fade-right">
            <a href="https://www.youtube.com/watch?v=yTzptgXWy90" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>
          </div>

          <div class="col-xl-7 col-lg-6 icon-boxes d-flex flex-column align-items-stretch justify-content-center py-5 px-lg-5" data-aos="fade-left">
            <h3>AePS - Aadhaar Enabled Payment System</h3>
            <p>DIGISAN offer Aadhaar enable payment system ( AEPS ) for our customers, Customers can use our platform for cash withdrawal & Balance check related services their aadhaar linked accounts. We offer attractive Cash back on banking services.</p>

            <div class="icon-box" data-aos="zoom-in" data-aos-delay="100">
              <div class="icon"><i class="bx bx-fingerprint"></i></div>
              <h4 class="title"><a href="">Cash Withdrawal</a></h4>
              <p class="description">AePS is a bank led model which allows online interoperable financial inclusion transaction at PoS (MicroATM) through the Business correspondent of any bank using the Aadhaar authentication.AePS allows you to do six types of transactions.</p>
            </div>

            <div class="icon-box" data-aos="zoom-in" data-aos-delay="200">
              <div class="icon"><i class="bx bx-fingerprint"></i></div>
              <h4 class="title"><a href="">Balance Enquiry</a></h4>
              <p class="description">AePS is a bank led model which allows online interoperable financial inclusion transaction at PoS (MicroATM) through the Business correspondent of any bank using the Aadhaar authentication.AePS allows you to do six types of transactions.</p>
            </div>

            <div class="icon-box" data-aos="zoom-in" data-aos-delay="300">
              <div class="icon"><i class="bx bx-fingerprint"></i></div>
              <h4 class="title"><a href="">Mini Statement</a></h4>
              <p class="description">AePS is a bank led model which allows online interoperable financial inclusion transaction at PoS (MicroATM) through the Business correspondent of any bank using the Aadhaar authentication.AePS allows you to do six types of transactions.</p>
            </div>

          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Features Section ======= -->
    <section id="features" class="features">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Our Services & Products</h2>
          <p>Check The Services & Products</p>
        </div>

        <div class="row" data-aos="fade-left">
          <div class="col-lg-3 col-md-4">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="50">
              <i class="bx bx-rupee" style="color: #ffbb2c;"></i>
              <h3><a href="#">Money Transfer</a></h3>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4 mt-md-0">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="100">
              <i class="bx bx-fingerprint" style="color: #5578ff;"></i>
              <h3><a href="#">AePS</a></h3>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4 mt-md-0">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="150">
              <i class="bx bxs-mobile" style="color: #e80368;"></i>
              <h3><a href="#">Prepaid Recharges</a></h3>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4 mt-md-0">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="150">
              <i class="bx bx-tv " style="color: #e80368;"></i>
              <h3><a href="#">DTH/TV Recharges</a></h3>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="200">
              <i class="ri-file-list-3-line" style="color: #e361ff;"></i>
              <h3><a href="#">Bill Payments</a></h3>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="250">
              <i class="bx bxs-id-card" style="color: #47aeff;"></i>
              <h3><a href="#">NSDL PAN Service</a></h3>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="300">
              <i class="bx bxs-id-card" style="color: #ffa76e;"></i>
              <h3><a href="#">PSA PAN Service</a></h3>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="400">
              <i class="ri-price-tag-2-line" style="color: #4233ff;"></i>
              <h3><a href="#">White Label</a></h3>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="350">
              <i class="bx bx-code-alt" style="color: #11dbcf;"></i>
              <h3><a href="#">B2B Software</a></h3>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="450">
              <i class="bx bx-code-block" style="color: #b2904f;"></i>
              <h3><a href="#">API Solution</a></h3>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="500">
              <i class="bx bxs-user-detail" style="color: #b20969;"></i>
              <h3><a href="#">Reseller Partner</a></h3>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 mt-4">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="550">
              <i class="bx bx-mail-send " style="color: #ff5828;"></i>
              <h3><a href="#">Bullk SMS</a></h3>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Features Section -->

    <!-- ======= Counts Section ======= -->
    <!--section id="counts" class="counts">
      <div class="container">

        <div class="row" data-aos="fade-up">

          <div class="col-lg-3 col-md-6">
            <div class="count-box">
              <i class="icofont-simple-smile"></i>
              <span data-toggle="counter-up">232</span>
              <p>Happy Clients</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-md-0">
            <div class="count-box">
              <i class="icofont-document-folder"></i>
              <span data-toggle="counter-up">521</span>
              <p>Projects</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="icofont-live-support"></i>
              <span data-toggle="counter-up">1,463</span>
              <p>Hours Of Support</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="icofont-users-alt-5"></i>
              <span data-toggle="counter-up">15</span>
              <p>Hard Workers</p>
            </div>
          </div>

        </div>

      </div>
    </section--><!-- End Counts Section -->

    <!-- ======= Details Section ======= -->
    <!--section id="details" class="details">
      <div class="container">

        <div class="row content">
          <div class="col-md-4" data-aos="fade-right">
            <img src="assets/img/details-1.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-8 pt-4" data-aos="fade-up">
            <h3>Voluptatem dignissimos provident quasi corporis voluptates sit assumenda.</h3>
            <p class="font-italic">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua.
            </p>
            <ul>
              <li><i class="icofont-check"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
              <li><i class="icofont-check"></i> Duis aute irure dolor in reprehenderit in voluptate velit.</li>
              <li><i class="icofont-check"></i> Iure at voluptas aspernatur dignissimos doloribus repudiandae.</li>
              <li><i class="icofont-check"></i> Est ipsa assumenda id facilis nesciunt placeat sed doloribus praesentium.</li>
            </ul>
            <p>
              Voluptas nisi in quia excepturi nihil voluptas nam et ut. Expedita omnis eum consequatur non. Sed in asperiores aut repellendus. Error quisquam ab maiores. Quibusdam sit in officia
            </p>
          </div>
        </div>

        <div class="row content">
          <div class="col-md-4 order-1 order-md-2" data-aos="fade-left">
            <img src="assets/img/details-2.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-8 pt-5 order-2 order-md-1" data-aos="fade-up">
            <h3>Corporis temporibus maiores provident</h3>
            <p class="font-italic">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua.
            </p>
            <p>
              Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
              velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
              culpa qui officia deserunt mollit anim id est laborum
            </p>
            <p>
              Inventore id enim dolor dicta qui et magni molestiae. Mollitia optio officia illum ut cupiditate eos autem. Soluta dolorum repellendus repellat amet autem rerum illum in. Quibusdam occaecati est nisi esse. Saepe aut dignissimos distinctio id enim.
            </p>
          </div>
        </div>

        <div class="row content">
          <div class="col-md-4" data-aos="fade-right">
            <img src="assets/img/details-3.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-8 pt-5" data-aos="fade-up">
            <h3>Sunt consequatur ad ut est nulla consectetur reiciendis animi voluptas</h3>
            <p>Cupiditate placeat cupiditate placeat est ipsam culpa. Delectus quia minima quod. Sunt saepe odit aut quia voluptatem hic voluptas dolor doloremque.</p>
            <ul>
              <li><i class="icofont-check"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
              <li><i class="icofont-check"></i> Duis aute irure dolor in reprehenderit in voluptate velit.</li>
              <li><i class="icofont-check"></i> Facilis ut et voluptatem aperiam. Autem soluta ad fugiat.</li>
            </ul>
            <p>
              Qui consequatur temporibus. Enim et corporis sit sunt harum praesentium suscipit ut voluptatem. Et nihil magni debitis consequatur est.
            </p>
            <p>
              Suscipit enim et. Ut optio esse quidem quam reiciendis esse odit excepturi. Vel dolores rerum soluta explicabo vel fugiat eum non.
            </p>
          </div>
        </div>

        <div class="row content">
          <div class="col-md-4 order-1 order-md-2" data-aos="fade-left">
            <img src="assets/img/details-4.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-8 pt-5 order-2 order-md-1" data-aos="fade-up">
            <h3>Quas et necessitatibus eaque impedit ipsum animi consequatur incidunt in</h3>
            <p class="font-italic">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua.
            </p>
            <p>
              Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
              velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
              culpa qui officia deserunt mollit anim id est laborum
            </p>
            <ul>
              <li><i class="icofont-check"></i> Et praesentium laboriosam architecto nam .</li>
              <li><i class="icofont-check"></i> Eius et voluptate. Enim earum tempore aliquid. Nobis et sunt consequatur. Aut repellat in numquam velit quo dignissimos et.</li>
              <li><i class="icofont-check"></i> Facilis ut et voluptatem aperiam. Autem soluta ad fugiat.</li>
            </ul>
          </div>
        </div>

      </div>
    </section--><!-- End Details Section -->

    <!-- ======= Gallery Section ======= -->
    <!--section id="gallery" class="gallery">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Gallery</h2>
          <p>Check our Gallery</p>
        </div>

        <div class="row no-gutters" data-aos="fade-left">

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item" data-aos="zoom-in" data-aos-delay="100">
              <a href="assets/img/gallery/gallery-1.jpg" class="venobox" data-gall="gallery-item">
                <img src="assets/img/gallery/gallery-1.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item" data-aos="zoom-in" data-aos-delay="150">
              <a href="assets/img/gallery/gallery-2.jpg" class="venobox" data-gall="gallery-item">
                <img src="assets/img/gallery/gallery-2.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item" data-aos="zoom-in" data-aos-delay="200">
              <a href="assets/img/gallery/gallery-3.jpg" class="venobox" data-gall="gallery-item">
                <img src="assets/img/gallery/gallery-3.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item" data-aos="zoom-in" data-aos-delay="250">
              <a href="assets/img/gallery/gallery-4.jpg" class="venobox" data-gall="gallery-item">
                <img src="assets/img/gallery/gallery-4.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item" data-aos="zoom-in" data-aos-delay="300">
              <a href="assets/img/gallery/gallery-5.jpg" class="venobox" data-gall="gallery-item">
                <img src="assets/img/gallery/gallery-5.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item" data-aos="zoom-in" data-aos-delay="350">
              <a href="assets/img/gallery/gallery-6.jpg" class="venobox" data-gall="gallery-item">
                <img src="assets/img/gallery/gallery-6.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item" data-aos="zoom-in" data-aos-delay="400">
              <a href="assets/img/gallery/gallery-7.jpg" class="venobox" data-gall="gallery-item">
                <img src="assets/img/gallery/gallery-7.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="gallery-item" data-aos="zoom-in" data-aos-delay="450">
              <a href="assets/img/gallery/gallery-8.jpg" class="venobox" data-gall="gallery-item">
                <img src="assets/img/gallery/gallery-8.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

        </div>

      </div>
    </section--><!-- End Gallery Section -->

    <!-- ======= Testimonials Section ======= -->
    <!--section id="testimonials" class="testimonials">
      <div class="container">

        <div class="owl-carousel testimonials-carousel" data-aos="zoom-in">

          <div class="testimonial-item">
            <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt="">
            <h3>Saul Goodman</h3>
            <h4>Ceo &amp; Founder</h4>
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
              Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit rhoncus. Accusantium quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at semper.
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
          </div>

          <div class="testimonial-item">
            <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt="">
            <h3>Sara Wilsson</h3>
            <h4>Designer</h4>
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
              Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum eram malis quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa.
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
          </div>

          <div class="testimonial-item">
            <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt="">
            <h3>Jena Karlis</h3>
            <h4>Store Owner</h4>
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
              Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam duis minim tempor labore quem eram duis noster aute amet eram fore quis sint minim.
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
          </div>

          <div class="testimonial-item">
            <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt="">
            <h3>Matt Brandon</h3>
            <h4>Freelancer</h4>
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
              Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat minim velit minim dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum veniam.
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
          </div>

          <div class="testimonial-item">
            <img src="assets/img/testimonials/testimonials-5.jpg" class="testimonial-img" alt="">
            <h3>John Larson</h3>
            <h4>Entrepreneur</h4>
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
              Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam enim culpa labore duis sunt culpa nulla illum cillum fugiat legam esse veniam culpa fore nisi cillum quid.
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
          </div>

        </div>

      </div>
    </section--><!-- End Testimonials Section -->

    <!-- ======= Team Section ======= -->
    <!--section id="team" class="team">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Team</h2>
          <p>Our Great Team</p>
        </div>

        <div class="row" data-aos="fade-left">

          <div class="col-lg-3 col-md-6">
            <div class="member" data-aos="zoom-in" data-aos-delay="100">
              <div class="pic"><img src="assets/img/team/team-1.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Walter White</h4>
                <span>Chief Executive Officer</span>
                <div class="social">
                  <a href=""><i class="icofont-twitter"></i></a>
                  <a href=""><i class="icofont-facebook"></i></a>
                  <a href=""><i class="icofont-instagram"></i></a>
                  <a href=""><i class="icofont-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-md-0">
            <div class="member" data-aos="zoom-in" data-aos-delay="200">
              <div class="pic"><img src="assets/img/team/team-2.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Sarah Jhonson</h4>
                <span>Product Manager</span>
                <div class="social">
                  <a href=""><i class="icofont-twitter"></i></a>
                  <a href=""><i class="icofont-facebook"></i></a>
                  <a href=""><i class="icofont-instagram"></i></a>
                  <a href=""><i class="icofont-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="member" data-aos="zoom-in" data-aos-delay="300">
              <div class="pic"><img src="assets/img/team/team-3.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>William Anderson</h4>
                <span>CTO</span>
                <div class="social">
                  <a href=""><i class="icofont-twitter"></i></a>
                  <a href=""><i class="icofont-facebook"></i></a>
                  <a href=""><i class="icofont-instagram"></i></a>
                  <a href=""><i class="icofont-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="member" data-aos="zoom-in" data-aos-delay="400">
              <div class="pic"><img src="assets/img/team/team-4.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Amanda Jepson</h4>
                <span>Accountant</span>
                <div class="social">
                  <a href=""><i class="icofont-twitter"></i></a>
                  <a href=""><i class="icofont-facebook"></i></a>
                  <a href=""><i class="icofont-instagram"></i></a>
                  <a href=""><i class="icofont-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section--><!-- End Team Section -->

    <!-- ======= Pricing Section ======= -->
    <section id="pricing" class="pricing">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Pricing</h2>
          <p>Check our Pricing</p>
        </div>

        <div class="row" data-aos="fade-left">

          <div class="col-lg-3 col-md-6">
            <div class="box" data-aos="zoom-in" data-aos-delay="100">
              <h3>Retailer</h3>
              <h4><sup>Rs.</sup></sup><?php echo $webdata['retailer'];?><span> / Charge</span></h4>
              <ul>
                <li>ICICI AEPS</li>
                <li>Money Transfer</li>
                <li>Mobile/DTH Recharge</li>
                <li>Utility Bill Payments</li>
                <li>PAN PSA Agent</li>
                <li>Automatic Refund</li>
                <li>High Margin</li>
                <li>Free 24/7 Support</li>
                <li>24/7 Billing</li>
              </ul>
              <div class="btn-wrap">
                <a href="portallogin/register.php?usertype=retailer" class="btn-buy">Register</a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-md-0">
            <div class="box featured" data-aos="zoom-in" data-aos-delay="200">
              <h3>Distributor</h3>
              <h4><sup>Rs.</sup><?php echo $webdata['distributor'];?><span> / Charge</span></h4>
              <ul>
                <li>Unlimited Retailers</li>
                <li>ICICI AEPS</li>
                <li>Money Transfer</li>
                <li>Mobile/DTH Recharge</li>
                <li>Utility Bill Payments</li>
                <li>PAN PSA Agent</li>
                <li>High Margin</li>
                <li>Free 24/7 Support</li>
                <li>24/7 Billing</li>
              </ul>
              <div class="btn-wrap">
                <a href="portallogin/register.php?usertype=distributor" class="btn-buy">Register</a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-lg-0">
            <div class="box" data-aos="zoom-in" data-aos-delay="300">
              <h3>Supper Distributor</h3>
              <h4><sup>Rs.</sup><?php echo $webdata['supperdistributor'];?><span> / Charge</span></h4>
              <ul>
                <li>Free Distributor / Retailers</li>
                <li>ICICI AEPS</li>
                <li>Money Transfer</li>
                <li>Mobile/DTH Recharge</li>
                <li>Utility Bill Payments</li>
                <li>PAN PSA Agent</li>
                <li>High Margin</li>
                <li>Free 24/7 Support</li>
                <li>24/7 Billing</li>
              </ul>
              <div class="btn-wrap">
                <a href="portallogin/register.php?usertype=supdistributor" class="btn-buy">Register</a>
              </div>
            </div>
          </div>

<div class="col-lg-3 col-md-6 mt-4 mt-lg-0">
            <div class="box" data-aos="zoom-in" data-aos-delay="400">
              <span class="advanced">Advanced</span>
              <h3>Api Partner</h3>
              <h4><sup>Rs.</sup>2999<span> / Charge</span></h4>
              <ul>
                <li>Unlimited Agent</li>
                <li>ICICI AEPS</li>
                <li>Money Transfer</li>
                <li>Mobile/DTH Recharge</li>
                <li>Utility Bill Payments</li>
                <li>Api Panel</li>
                <li>Api Docs</li>
                <li>Free 24/7 Support</li>
                <li>24/7 Billing</li>
              </ul>
              <div class="btn-wrap">
                <a href="wlregister.php" class="btn-buy">Register</a>
              </div>
            </div>
          </div>
          
</div>

      </div>
    </section><!-- End Pricing Section -->

    <!-- ======= F.A.Q Section ======= -->
    <section id="faq" class="faq section-bg">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>F.A.Q</h2>
          <p>Frequently Asked Questions</p>
        </div>

        <div class="faq-list">
          <ul>
            <li data-aos="fade-up">
              <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" class="collapse" href="#faq-list-1">Distributor or Supper Distributor can be Create Unlimited Free Distributor and Retailer ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-1" class="collapse" data-parent=".faq-list">
                <p>
                  Yes, Super Distributor Unlimited Distributor and Retailer, Distributor Unlimited Retailer, Within Seconds.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="100">
              <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-2" class="collapsed">ID Activation and Coupon Approved Time ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-2" class="collapse" data-parent=".faq-list">
                <p>
                  Normally ID Activation Within Second, and Coupon Approved Within Second, Depends on Server.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="200">
              <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-3" class="collapsed">AePS Cash Withdrawal Instant Settlement Available ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-3" class="collapse" data-parent=".faq-list">
                <p>
                 Yes, IMPS and NEFT Options is Available.
                </p>    
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="300">
              <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-4" class="collapsed">I Can Load My Wallet Balance Instant and Without Pay Extra Charges ?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-4" class="collapse" data-parent=".faq-list">
                <p>
                Yes, Payment Gateway and Without Extra Charges , But UPI Payment Only.
                </p>
              </div>
            </li>

            <!--li data-aos="fade-up" data-aos-delay="400">
              <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-5" class="collapsed">Tortor vitae purus faucibus ornare. Varius vel pharetra vel turpis nunc eget lorem dolor? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-5" class="collapse" data-parent=".faq-list">
                <p>
                  Laoreet sit amet cursus sit amet dictum sit amet justo. Mauris vitae ultricies leo integer malesuada nunc vel. Tincidunt eget nullam non nisi est sit amet. Turpis nunc eget lorem dolor sed. Ut venenatis tellus in metus vulputate eu scelerisque.
                </p>
              </div>
            </li-->

          </ul>
        </div>

      </div>
    </section><!-- End F.A.Q Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Contact</h2>
          <p>Contact Us</p>
        </div>

        <div class="row">

          <div class="col-lg-8" data-aos="fade-right" data-aos-delay="100">
            <div class="info">
              <div class="address">
                <i class="icofont-google-map"></i>
                <h4>Location:</h4>
                <p><?php echo $webdata['address1'];?><br>
         <?php echo $webdata['address2'];?><br>
         <?php echo $webdata['address3'];?></p>
              </div>

              <div class="email">
                <i class="icofont-envelope"></i>
                <h4>Email:</h4>
                <p><?php echo $webdata['webemail'];?></p>
              </div>

              <div class="phone">
                <i class="icofont-phone"></i>
                <h4>Call:</h4>
                <p><?php echo $webdata['webmob1'];?> / <?php echo $webdata['webmob2'];?><br>
                <?php echo $webdata['timings'];?></p>
              </div>

            </div>

          </div>

          <div class="col-lg-4 mt-5 mt-lg-0 text-center" data-aos="fade-left" data-aos-delay="200">
              
          <h6 class="mb-4">WHATSAPP CHAT SUPPORT</h6>    
          <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://wa.me/91<?php echo $webdata['webmob1'];?>"><br>
          <span class="mt-3">SCAN QR CODE</span>    
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="footer-info">
              <h3>CONTACT US</h3>
              
            <div class="info">
              <div class="address">
                <i class="icofont-google-map"></i>
                <h4>Location:</h4>
                <p><?php echo $webdata['address1'];?><br>
         <?php echo $webdata['address2'];?><br>
         <?php echo $webdata['address3'];?>,</p>
              </div>

              <div class="email">
                <i class="icofont-envelope"></i>
                <h4>Email:</h4>
                <p><?php echo $webdata['webemail'];?></p>
              </div>

              <div class="phone">
                <i class="icofont-phone"></i>
                <h4>Call:</h4>
                <p><?php echo $webdata['webmob1'];?> /<br>
               <?php echo $webdata['webmob2'];?></p>
              </div>

            </div>
              
            </div>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Login</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#pricing">Pricing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#faq">FAQ</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#features">ICICI AEPS</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#features">Money Transfer</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#features">Muti Recharges</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#features">Utility Bill Payments</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#features">UTI Pan Card</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#features">White Label Website</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#features">Admin Panel</a></li>
            </ul>
          </div>
<style>
.footer-newsletter form input[type="text_cust"] {
    border: 0;
    padding: 4px;
    width: calc(100% - 110px);
}
</style>
          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>WhatsApp Messenger</h4>
            <p>First Scan QR Code and Save the Number.<br>
            Next Try This Message Option</p>
            <form action="https://wa.me/send?" method="get" target="_blank">
              <input type="hidden" name="phone" value="91<?php echo $webdata['webmob1'];?>">  
              <input type="text_cust" placeholder="Enter Your Message" name="text">
              <input type="submit" value="Send">
            </form>

          </div>

        </div>
      </div>
    </div>
<!-- Modal -->
<div class="modal fade" id="BuyCoupon" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="background:#010479">
      <div class="modal-header">
        <h5 class="modal-title text-white" id="exampleModalLabel">Online Coupon Purchase</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="onlinecoupon.php" method="post">
          <div class="form-group">
              <label for="vle_id" class="text-white" >VLE LOGIN ID <span class="text-danger">*</span></label>
            <input type="text" class="form-control form-control-sm" placeholder="VLE LOGIN ID" name="vle_id" onchange="GetUsrData(this.value)" required>
          </div>
          <div id="ajax_load"></div>
          <div style="display:none;" id="myDIV">
          <div class="form-group">
              <label for="mobile" class="text-white">VLE Name</label>
            <input type="text" class="form-control form-control-sm" id="vle_name" placeholder="VLE Name" name="vle_name" required="" readonly>
          </div>
          <div class="form-group">
              <label for="qty" class="text-white">No Of Coupon</label>
            <input type="number" class="form-control form-control-sm"  placeholder="No Of Coupon" name="qty" required="" min="1">
          </div>
          </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary text-white" data-dismiss="modal">Close</button>
        <button type="submit" name="payment" class="btn btn-info text-white">Pay Now</button>
      </div>
      </form>
    </div>
  </div>
</div>

<script>
function GetUsrData(vle_id) {
if(!vle_id==""){
document.getElementById('ajax_load').innerHTML = '<img src="https://billpay.axisbank.co.in/billzone/JS/ajax-loader.gif">';
$.ajax({
url: 'onlinecoupon.php',
type: 'POST',
data: {getvle:'yes',vle_id:vle_id},
success: function (result) {
if(result==0){
document.getElementById('ajax_load').innerHTML = '';        
document.getElementById("myDIV").style.display = "none";    
alert("Invalid VLE Login Id!");     
}else{
document.getElementById('ajax_load').innerHTML = '';    
document.getElementById("myDIV").style.display = "block";
document.getElementById("vle_name").value = result;   
}    



}

});     
}  else { 
document.getElementById("myDIV").style.display = "none";    
alert("Please Enter VLE Login Id!");
}   

}
</script>


<!-- Login modal -->
<div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">   
    <div class="modal-content">
    
   <div class="modal-header">
        <h5 class="modal-title text-primary" id="exampleModalLabel">Smart Login</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>    
      <div class="modal-body">
      <form class="user" action="portallogin/login.php" method="POST">
     <div class="form-group">
     <input type="text" class="form-control form-control-user" name="username" aria-describedby="emailHelp" placeholder="Enter Username" onkeyup="this.value = this.value.toUpperCase();" onblur="this.value = this.value.toUpperCase();">
                    </div>
                    <div class="form-group">
                      <input type="password" class="form-control form-control-user" name="password" placeholder="Password">
                    </div>
                    <div class="form-group">
                      <div class="custom-control custom-checkbox small">
                        <input type="checkbox" class="custom-control-input" id="customCheck" name="remember" value="1">
                        <label class="custom-control-label text-primary" for="customCheck">Remember Me</label>
                      </div>
                    </div>
   <input type="submit" class="btn btn-primary btn-user btn-block" name="login_user" value="Login">
    </form>
      
    </div> 
    </div> 
  </div>
</div>


    <div class="container">
      <div class="copyright">
       <?php echo $webdata['copyright'];?>      </div>
      <!--div class="credits">
        Developer by <a href="https://digisan.in/">digisan Infotech</a>
      </div-->
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  </body>

</html>