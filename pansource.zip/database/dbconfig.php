<?php
$servername = "localhost";
$username = "onlinese_new";
$password = "onlinese_new";
$dbname = "onlinese_new";
$driver = "mysql";
$socket = "http://";
?>